declare module 'react-native-screenshot-prevent' {
  export function enabled(value: boolean): void
}