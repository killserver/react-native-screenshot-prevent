import { NativeModules } from 'react-native';

const { RNScreenshotPrevent } = NativeModules;

export default RNScreenshotPrevent;
